package com.selenium.Driver;

import java.util.Scanner;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.safari.SafariDriver;

public class Driver {
	protected static WebDriver driver;

	public static WebDriver drivers() {

		Scanner sc = new Scanner(System.in);

		String name = sc.next();

		if (name.equalsIgnoreCase("Chrome")) {
			driver = new ChromeDriver();
		} else if (name.equalsIgnoreCase("Edge")) {
			driver = new EdgeDriver();
		} else if (name.equalsIgnoreCase("FireFox")) {
			driver = new FirefoxDriver();
		} else if (name.equalsIgnoreCase("Safari")) {
			driver = new SafariDriver();
		} else {
			System.out.println("Please select a valid Browser name");
		}
		return driver;

	}
}
