package com.selenium.Main;

import java.time.Duration;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import com.selenium.Driver.*;

public class FindMulti {
	
	// Click on Help button,Click on Online Chat Support button,Click on Visit Us

	public static void ClickCHV(WebDriver driver, String Chat, String Help, String Visit) throws InterruptedException {

		WebElement clickChat = driver.findElement(By.id(Chat));
		
		// clicking on ChatBox Button
		
		clickChat.click();

		TimeUnit.SECONDS.sleep(5);

		WebElement ClickHe = driver.findElement(By.id(Help));
		
		// clicking on Help Button
		
		ClickHe.click();

		TimeUnit.SECONDS.sleep(5);

		WebElement clickVis = driver.findElement(By.id(Visit));
		
		// clicking on Visit us Button
		
		clickVis.click();

	}

	// Configure your car: White BMW Diesel car with “Parking Sensor"

	public static void SelectMul(WebDriver driver, String CarName, String Color, String Feature, String Fuel)
			throws InterruptedException {
		WebElement carNam = driver.findElement(By.name(CarName));

		Select CarName1 = new Select(carNam);
		
		//Selecting Carname

		CarName1.selectByIndex(0);

		TimeUnit.SECONDS.sleep(5);

		WebElement SeCo1 = driver.findElement(By.name(Color));

		Select Seco = new Select(SeCo1);
		
		//Selecting color

		Seco.selectByValue("wt");

		TimeUnit.SECONDS.sleep(5);

		WebElement selectFeatu1 = driver.findElement(By.name(Feature));

		selectFeatu1.click();

		TimeUnit.SECONDS.sleep(5);

		WebElement SeleFuel = driver.findElement(By.cssSelector(Fuel));

		SeleFuel.click();
	}

	
	public static void main(String[] args) throws InterruptedException {
		System.out.println("Enter a Browser name");

		String url = "http://cookbook.seleniumacademy.com/Config.html";

		// Calling WebDriver by importing from Driver package

		WebDriver driver = Driver.drivers();

		driver.get(url);

		driver.manage().window().maximize();

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

		String Secol = "color", CarName = "make", FuelName = "input[value='Diesel']", carFeau = "parksensor";

		// Passing parameters to select options

		SelectMul(driver, CarName, Secol, carFeau, FuelName);

		String clicHel = "helpbutton", clicChat = "chatbutton", clicVisit = "visitbutton";

		// Passing parameters to click the button

		ClickCHV(driver, clicChat, clicHel, clicVisit);

		Set<String> count = driver.getWindowHandles();

		// print the number of browser windows opened

		System.out.println("Number of browser windows opened -> " + count.size() + "\n");
		
	    //Verifying the title name of webpage
	
		boolean flag = true;
		for (String Vname : count) {

			if (driver.switchTo().window(Vname).getTitle().equals("Visit Us")) {
				flag = false;
				TimeUnit.SECONDS.sleep(5);
				System.out.println(driver.switchTo().window(Vname).getTitle() + "\n");

				System.out.println("Visit Us is Found \n");

				driver.close();
			}
		}
		
		//if Verified title not Visit us 
		if (flag == true) {
			System.out.println("Invalid Title");
		}

		TimeUnit.SECONDS.sleep(5);

		// Navigate back to main browser window.

		driver.navigate().to(url);

		driver.quit();

	}

}