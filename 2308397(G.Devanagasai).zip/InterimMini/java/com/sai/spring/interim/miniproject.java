package com.sai.spring.interim;

import java.util.Set;

import org.openqa.selenium.By;

import org.openqa.selenium.WebElement;

import org.openqa.selenium.JavascriptExecutor;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.chrome.ChromeDriver;


import org.openqa.selenium.interactions.Actions;

public class miniproject {

	public static void main(String[] args) throws InterruptedException {

		WebDriver driver = new ChromeDriver();	
		
		driver.get("http://cookbook.seleniumacademy.com/Config.html");

		driver.manage().window().maximize();

		Thread.sleep(3000);

		WebElement parking = driver.findElement(By.xpath("//input[@name=\"parksensor\"]"));

		parking.click();

		Thread.sleep(3000);

		WebElement fueltype = driver.findElement(By.xpath("//input[@value=\"Diesel\"]"));

		fueltype.click();

		WebElement scrollableElement = driver.findElement(By.xpath("//select[@name=\"color\"]"));

		((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);",scrollableElement);

		WebElement desiredOption = driver.findElement(By.xpath("//select[@name=\"color\"]//option[text()='White']"));

		Actions actions = new Actions(driver);

		actions.moveToElement(desiredOption).click().perform();

		Thread.sleep(2000);

		WebElement cartype = driver.findElement(By.xpath("//select[@name=\"make\"]//option[text()='Audi']"));

		cartype.click();

		Thread.sleep(2000);

		driver.findElement(By.id("helpbutton")).click();

		Thread.sleep(2000);

		driver.findElement(By.id("chatbutton")).click();

		Thread.sleep(2000);

		driver.findElement(By.id("visitbutton")).click();

		int numberOfWindows = driver.getWindowHandles().size();

		System.out.println("Number of open browser windows: " + numberOfWindows);

		Set<String> windowHandles = driver.getWindowHandles();

		for (String WindowHandle : windowHandles) {

			driver.switchTo().window(WindowHandle);

			System.out.println("Window Title"+ driver.getTitle());

			for (String windowHandle : windowHandles) {

				driver.switchTo().window(windowHandle);

				if (driver.getTitle().equals("Visit Us")) {

					System.out.println("Found window with title 'Visit Us'.");

		            driver.close();

				}


			}

			driver.navigate().to("http://cookbook.seleniumacademy.com/Config.html "); 

			driver.quit();

		}

		driver.quit();

	}



}


