package com.sai.spring.springcore;

import java.util.Scanner;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.Select;

public class MyPract {

	public static void main(String[] args) throws InterruptedException {
		Scanner sc = new Scanner(System.in);
		System.out.println("Press 1 and enter to open CHROME / Press 2 and enter to open EDGE");
		int n = sc.nextInt();
		WebDriver driver = null;
		if (n == 1) {
			driver = new ChromeDriver();
			driver.get("http://cookbook.seleniumacademy.com/Config.html");
		} else if (n == 2) {
			driver = new EdgeDriver();
			driver.get("http://cookbook.seleniumacademy.com/Config.html");
		}

		driver.manage().window().maximize();

		Thread.sleep(4000);

		WebElement sco = driver.findElement(By.name("color"));
		Select co = new Select(sco);
		co.selectByVisibleText("White");

		Thread.sleep(4000);

		WebElement cna = driver.findElement(By.name("make"));
		Select cn = new Select(cna);
		cn.selectByVisibleText("BMW");
		cna.click();
		
		Thread.sleep(4000);
		
		WebElement oil = driver.findElement(By.cssSelector("input[value='Diesel']"));
		oil.click();
		
		Thread.sleep(4000);
		
		WebElement feat=driver.findElement(By.xpath("//input[@value='ParkingSensor']"));
		feat.click();
		
		Thread.sleep(4000);
		
		driver.findElement(By.id("helpbutton")).click();

		Thread.sleep(2000);

		driver.findElement(By.id("chatbutton")).click();

		Thread.sleep(2000);

		driver.findElement(By.id("visitbutton")).click();		
		
	}

}
