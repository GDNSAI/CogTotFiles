package com.sai.spring.springcore;

import java.util.Scanner;

import org.openqa.selenium.By;
import org.openqa.selenium.By.ById;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class Test {

	public static void main(String[] args) throws InterruptedException 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter 1 to open in Chrome ");
		System.out.println("Enter 2 to open in Edge ");
		int n = sc.nextInt();
		WebDriver driver = null;
		if (n == 2) 
		{
			driver = new EdgeDriver();
			driver.get("https://practicetestautomation.com/practice-test-login/");
		} 
		else if (n == 1) 
		{
			driver = new ChromeDriver();
			driver.get("https://practicetestautomation.com/practice-test-login/");
		}
		
		String na = sc.next();
		
		//driver.findElement(By.id("username")).sendKeys(na);
		
		WebElement username = driver.findElement(By.id("username"));
		
		username.sendKeys(na);
		
		String pas = sc.next();
		
		//driver.findElement(By.id("password")).sendKeys(pas);
		
		WebElement password = driver.findElement(By.id("password"));
		
		password.sendKeys(pas);
		
		//driver.findElement(By.id("submit"));
		
		WebElement submit = driver.findElement(By.id("submit"));
		
		submit.click();
		
		Thread.sleep(2000);
		
		driver.findElement(By.linkText("Log out")).click();
	}

}
